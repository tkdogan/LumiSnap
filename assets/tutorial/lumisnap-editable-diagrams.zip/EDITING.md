# LumiSnap HDR field guide diagrams

Open any SVG directly in Adobe Illustrator or Inkscape. Labels are live Arial text; shapes, paths and annotations remain editable. The sample photograph is an embedded JPEG. The diagrams have no external dependencies. Editing an SVG does not require rerunning a generator.

The photograph and readings are supplied course examples. Timestamps differ; the readings illustrate target selection and are not a validated calibration of the displayed frame.

Guide, references and image notes: https://lumisnap.io/guide.html
